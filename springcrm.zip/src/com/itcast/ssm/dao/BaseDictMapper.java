package com.itcast.ssm.dao;

import java.util.List;

import com.itcast.ssm.pojo.BaseDict;

public interface BaseDictMapper {
	
	/*
	 * 通过base_dict字典包中的 type_code字段来查询客户信息
	 */
	public List<BaseDict> getListBaseDictByTypeCode (String typeCode) throws Exception;
}

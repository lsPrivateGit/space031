package com.itcast.ssm.dao;

import java.util.List;

import com.itcast.ssm.pojo.Customer;
import com.itcast.ssm.pojo.QueryVo;

public interface CustomerMapper {
	
	
	public List<Customer> getCustomerByQueryVo(QueryVo vo) throws Exception;
	
	public int getCount(QueryVo vo) throws Exception;
	
	public Customer getCustomerById(Long id) throws Exception;
	
	public void updateCustomer(Customer customer) throws Exception;
	
	public void deleteCustomer(Long id) throws Exception;
}

package com.itcast.ssm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.itcast.ssm.pojo.BaseDict;
import com.itcast.ssm.pojo.Customer;
import com.itcast.ssm.pojo.QueryVo;
import com.itcast.ssm.service.BaseDictService;
import com.itcast.ssm.service.CustomerService;
import com.itcast.ssm.utils.Constants;
import com.itcast.ssm.utils.Page;

/**
 *  处理 Customer的前端控制器
 */
@Controller
public class CustomerController {
	
	
	@Autowired
	private BaseDictService baseDictService;
	
	@Autowired
	private CustomerService customerService;
	
	@RequestMapping(value="/customer/list",method=RequestMethod.GET)
	public String listCustomer(Model model,QueryVo vo) throws Exception{
		
		List<BaseDict> listIndustry = baseDictService.getListBaseDictByTypeCode(Constants.CON_CUST_INDUSTRY);//客户所属行业
		List<BaseDict> listLevel = baseDictService.getListBaseDictByTypeCode(Constants.CON_CUST_LEVEL);//客户级别
		List<BaseDict> listSource = baseDictService.getListBaseDictByTypeCode(Constants.CON_CUST_SOURCE); // 客户来源
		
		
		
		Page<Customer>  pageList = customerService.pageCustomer(vo); //查询客户分页信息
		
		model.addAttribute("page", pageList);
		
		//查询条件数据 回显
		if(vo.getCustName()!=null){
			model.addAttribute("custName", vo.getCustName());
		}
		if(vo.getCustIndustry()!=null){
			model.addAttribute("custIndustry", vo.getCustIndustry());
		}
		if(vo.getCustSource()!=null){
			model.addAttribute("custSource", vo.getCustSource());
		}
		if(vo.getCustLevel()!=null){
			model.addAttribute("custLevel", vo.getCustLevel());
		}
		
		//将查询的客户信息存到request中
		model.addAttribute("listIndustry", listIndustry);
		model.addAttribute("listLevel", listLevel);
		model.addAttribute("listSource", listSource);
		
		return "customer";//直接返回 customer，是因为在spirngmvc.xml中配置了视图解析器的前缀和后缀
	}
	
	/*
	 * 根据id查询用户信息回显，返回JOSN数据
	 */
	 @RequestMapping(value="/customer/edit",method=RequestMethod.GET)
	 @ResponseBody
	 public Customer getCustomer(Long id) throws Exception{
		System.out.println("<<<<<<<<<<获取的用户ID是：>>>>>>>"+id);
		Customer customer = customerService.getCustomerById(id);
		return customer;
	 }
	
	// TODO  //TODO 
	 // TODO  为何这里ID为 null 呢？      因为没有给   $("#edit_cust_id").val(msg.cust_id); cust_id赋值，虽然定义了一个隐藏域，但是没有值
	 /*
	  * 更新客户信息
	  */
	 @RequestMapping(value="/customer/update",method=RequestMethod.POST)
	 @ResponseBody
	 public Customer updateCustomer(Customer customer) throws Exception{
		 System.out.println("要更改的用户id是："+customer.getCust_id());
		 customerService.updateCustomer(customer);
		 return customer;
	 }
	
	 
	 
	 //根据客户id删除客户信息
	 @RequestMapping(value="/customer/deleteCustomer",method=RequestMethod.GET)
	 public String deleteCustomer(Long id) throws Exception{
		 System.out.println("id="+id);
		 customerService.deleteCustomer(id);
		 return "customer";
	 }
	
}

package com.itcast.ssm.pojo;

/*http://localhost:8180/springcrm/customer/list.action?custName=www&custSource=6&custIndustry=1&custLevel=22
 * 
 * 如上图的查询拼接条件，因为条件查询用户信息会拼接成上面那样，所有定义一个QueryVo类，来包含用户查询信息；
 */
public class QueryVo {
	
	private String custName; // 客户姓名
	private String custSource;// 客户来源
	private String custIndustry;// 客户所属行业
	private String custLevel;// 客户级别
	
	
	/**************因为 mysql 分页 查询条件 后面带了 limit ，所以这里在定义一个  limit start ,size 条件 ********************/
	private Integer page; // 表示当前页码，注意，这里必须定义成page，因为分页的条件就是这个变量
	private Integer rows; // 表示每页显示数量
	private Integer start; // 开始分页的位置        limit  start  , rows  等价于————————>> limit (page-1)*rows, rows
	
	
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	public Integer getRows() {
		return rows;
	}
	public void setRows(Integer rows) {
		this.rows = rows;
	}
	public Integer getStart() {
		return start;
	}
	public void setStart(Integer start) {
		this.start = start;
	}
	
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustSource() {
		return custSource;
	}
	public void setCustSource(String custSource) {
		this.custSource = custSource;
	}
	public String getCustIndustry() {
		return custIndustry;
	}
	public void setCustIndustry(String custIndustry) {
		this.custIndustry = custIndustry;
	}
	public String getCustLevel() {
		return custLevel;
	}
	public void setCustLevel(String custLevel) {
		this.custLevel = custLevel;
	}
	
	
	
	
}

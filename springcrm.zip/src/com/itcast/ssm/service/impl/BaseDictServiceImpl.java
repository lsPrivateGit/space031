package com.itcast.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itcast.ssm.dao.BaseDictMapper;
import com.itcast.ssm.pojo.BaseDict;
import com.itcast.ssm.service.BaseDictService;

@Service
public class BaseDictServiceImpl implements BaseDictService {

	@Autowired
	private BaseDictMapper baseDictMapper; // 注入 BaseDictMapper的bean
	
	@Override
	public List<BaseDict> getListBaseDictByTypeCode(String typeCode) throws Exception {
		
		return baseDictMapper.getListBaseDictByTypeCode(typeCode);
	}

}

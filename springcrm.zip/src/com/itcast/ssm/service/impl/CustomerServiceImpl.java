package com.itcast.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itcast.ssm.dao.CustomerMapper;
import com.itcast.ssm.pojo.Customer;
import com.itcast.ssm.pojo.QueryVo;
import com.itcast.ssm.service.CustomerService;
import com.itcast.ssm.utils.Page;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerMapper customerMapper;
	
	/**
	 * 注意：这里查询的是封装了分页信息的 Page<Customer>集合
	 */
	@Override
	public Page<Customer> pageCustomer(QueryVo vo) throws Exception {
		/************用于判断当前分页显示页码是否为空，为空则为其赋值   *********/
		if(vo!=null){
			if(vo.getPage()==null) vo.setPage(1);//设置为第一页
			if(vo.getRows()==null) vo.setRows(10);//设置每页显示10条数据
			
			//计算start: (page-1)*rows
			vo.setStart((vo.getPage()-1)*vo.getRows());
		}
		
		List<Customer> rows = customerMapper.getCustomerByQueryVo(vo);
		int total = customerMapper.getCount(vo);
		
		//封装Page集合
		Page<Customer> pageInfo = new Page<>();
		pageInfo.setPage(vo.getPage());//封装当前页码
		pageInfo.setSize(vo.getRows());
		pageInfo.setTotal(total);
		pageInfo.setRows(rows);
		
		
		return pageInfo;
	}

	@Override
	public Customer getCustomerById(Long id) throws Exception {
		return customerMapper.getCustomerById(id);
	}

	@Override
	public void updateCustomer(Customer customer) throws Exception {
		customerMapper.updateCustomer(customer);
	}

	@Override
	public void deleteCustomer(Long id) throws Exception {
		customerMapper.deleteCustomer(id);
	}

}

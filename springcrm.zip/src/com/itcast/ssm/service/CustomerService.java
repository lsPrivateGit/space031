package com.itcast.ssm.service;

import com.itcast.ssm.pojo.Customer;
import com.itcast.ssm.pojo.QueryVo;
import com.itcast.ssm.utils.Page;

public interface CustomerService {
	
	
	public Page<Customer> pageCustomer(QueryVo vo) throws Exception;
	
	
	public Customer getCustomerById(Long id) throws Exception;
	
	
	public void updateCustomer(Customer customer) throws Exception;
	
	
	public void deleteCustomer(Long id) throws Exception;
}

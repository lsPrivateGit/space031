package com.itcast.ssm.service;

import java.util.List;

import com.itcast.ssm.pojo.BaseDict;

public interface BaseDictService {

	public List<BaseDict> getListBaseDictByTypeCode (String typeCode) throws Exception;
}
